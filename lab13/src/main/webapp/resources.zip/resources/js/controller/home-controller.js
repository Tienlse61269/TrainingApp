

  // Controller definition
  controllers.controller('HomeController', [
    '$scope',
    '$http',
    function ($scope,$http) {
    $scope.getEmployees = function(){
      $http.get("employees/getAll",{
          ignoreLoadingBar:false,
          timeout:10000
      }).then(function(res){
         $scope.employees = res.data;
         $scope.employees.forEach(function(employee){
        	 employee.change=false;
         });
         console.log("employees");
         console.log(res);
      });  
    };
    $scope.add = function()
    {
    	$scope.change=true;
    	$scope.showID  = true;
    };
   $scope.changeStatus = function(employee)
   {	
	   $scope.change=true;
       employee.change=true;
       $scope.selectedId = employee.id;
       $scope.selectedName = employee.name;
       $scope.selectedAge = employee.age;
   };
   $scope.addEmployee = function()
   {
	   $http.get("employees/add?name="+ $scope.selectedName+
			   "&age="+ $scope.selectedAge,{
	          ignoreLoadingBar:false,
	          timeout:10000
	      }).then(function(res){
	    	  console.log("data");
	    	  console.log(res.data);
	    	  var data = res.data;
	    	  data.change=false;
	    	  $scope.employees.push(data);
	      });
   };
   $scope.updateEmployee = function()
   {
	   console.log("name and age :"+$scope.selectedName +" and "+ $scope.selectedAge);
	   $http.get("employees/update?id="+ $scope.selectedId+
			   "&name="+ $scope.selectedName+
			   "&age="+ $scope.selectedAge,{
	          ignoreLoadingBar:false,
	          timeout:10000
	      }).then(function(res){
	    	  console.log("data");
	    	  console.log(res.data);
	    	  var data = res.data;
	    	  $scope.employees.forEach(function(employee){
	    		  if (employee.id==data.id)
	    			  {
	    		  employee.name = data.name;
	    		  employee.age = data.age;
	    		  employee.change = false;
	    			  }
	    	  });
	      });
   };
   $scope.deleteEmployee = function()
   {
	   $http.get("employees/delete?id="+$scope.selectedId,{
	          ignoreLoadingBar:false,
	          timeout:10000
	      }).then(function(res){
	    	  var data = res.data;
	    	  if (data== "OK")
	    	  $scope.employees.forEach(function(employee){
	    		 if (employee.id==$scope.selectedId)
	    			 $scope.employees.splice($scope.employees.indexOf(employee),1);
	    	  });
	      });
   };
      (function init() {
        $scope.getEmployees();
       $scope.change = false;
       $scope.showID  = true;
      })();


    }]);


