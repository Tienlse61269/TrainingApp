var routerApp = angular.module('routerApp', ['ui.router', 'ui.bootstrap'] );
routerApp.config(function($stateProvider, $urlRouterProvider) {
//    $urlRouterProvider.otherwise('/home');
    $stateProvider
        // HOME STATES AND NESTED VIEWS ========================================
        .state('home', {
            url: '/home',
            templateUrl: 'resources/html/partial-home.html'
        })
         .state('home.list', {
        url: '/list',
        templateUrl: 'resources/html/partial-home-list.html',
        controller: function($scope) {
            $scope.dogs = ['Bernese', 'Husky', 'Goldendoodle'];
        }
        })
        // nested list with just some random string data
        .state('home.paragraph', {
            url: '/paragraph',
            template: 'I could sure use a drink right now.'
        })
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        .state('about', {
            url: '/about',
            
                templateUrl: 'resources/html/table-data.html',
                controller: 'scotchController'
            
            
        });
        
});
routerApp.controller('scotchController', function($scope,$http) {
    $scope.filteredTodos = [];
    $scope.currentPage = 1;
    $scope.numPerPage = 9;
    $http.get("/tour/getAll", {
	    	          ignoreLoadingBar: false,
	    	          timeout: 0
	    	        }).then(function (res) {
	    	        	$scope.tours = res.data; 
	    	        	
	    	        }).then(function (){
                            $scope.$watch('currentPage + numPerPage', function() {
                                var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                                , end = begin + $scope.numPerPage;
                                $scope.filteredTodos = $scope.tours.slice(begin, end);
                                console.log($scope.filteredTodos);
                            });
                        });
    
    
});
